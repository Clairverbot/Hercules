from flask import Flask, request
app = Flask('app')
import requests

lta_headers = {
    'AccountKey': '0agVJJibSRW7VLcuFbjjOg==',
    'accept': 'application/json'
}

onemap_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjMyMDAsInVzZXJfaWQiOjMyMDAsImVtYWlsIjoiY2xhaXJlLnh3MjA1QGdtYWlsLmNvbSIsImZvcmV2ZXIiOmZhbHNlLCJpc3MiOiJodHRwOlwvXC9vbTIuZGZlLm9uZW1hcC5zZ1wvYXBpXC92MlwvdXNlclwvc2Vzc2lvbiIsImlhdCI6MTU4OTA0MTg2OCwiZXhwIjoxNTg5NDczODY4LCJuYmYiOjE1ODkwNDE4NjgsImp0aSI6Ijk5ZDhlZTJlMGY4MmM3NjNkOWM1ZjgxM2RlYjA0OTU2In0.HfoUulDU9dCzbMSmGI12BKsZtdzYgJ39hTTZ-8gTL7M"


@app.route('/')
def hello_world():
    return 'Hello, World!'


@app.route('/getBusData')
def get_bus_data():
    busStopCode = request.args.get('busStopCode')
    serviceNo = request.args.get('serviceNo')
    return requests.get(
        "http://datamall2.mytransport.sg/ltaodataservice/BusArrivalv2?BusStopCode="
        + busStopCode + "&ServiceN0=" + serviceNo,
        headers=lta_headers).json()


@app.route('/getRoute')
def get_route():
    startLatLong = request.args.get('startLatLong')
    endLatLong = request.args.get('endLatLong')
    date = request.args.get('date')
    time = request.args.get('time')
    mode = 'bus'
    return requests.get(
        "https://developers.onemap.sg/privateapi/routingsvc/route?start=" +
        startLatLong + "&end=" + endLatLong + "&routeType=pt" + 
        "&token=" + onemap_token + "&date=" + date + "&time=" + time+"&mode="+mode).json()


app.run(host='0.0.0.0', port=8080)
